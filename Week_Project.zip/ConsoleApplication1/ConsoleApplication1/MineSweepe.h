#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <memory.h>
#include <time.h>
#include <ctype.h>
#include <iostream>

using namespace std;

extern void PlayMainSweeper(int width = 3, int height = 3 ,int nBome = 13);
