#include<iostream>

using namespace std;

enum Status {
	namal = 0,
	abnomal,
	disconnect = 100,
	close
};

enum class Machstatus : char {
	nomal = 'n',
	abnomal,
	disconnect = 100,
	close
};

enum baceballTeam {
	BEARS,
	ENGLES,
	GIANTS,
	LIONS,
	TIGERS,
	HEROSE,
	DRAGON,
	WABENS

};

int main() {

	Machstatus machine = Machstatus::abnomal;

	if (machine == Machstatus::nomal) {
		cout << "Status : namal" << endl;
	}
	else if (machine == Machstatus::abnomal) {
		cout << "Status : abnomal" << endl;
	}
	else if (machine == Machstatus::disconnect) {
		cout << "Status : disconnect" << endl;
	}
	else {
		cout << "Status : close" << endl;
	}

	cout << "machine : " << (int)(machine) << "," << (char)(machine) << endl;

	int data1[2][2] = { 1,2,3 };
	int data2[2][3] = { {1, } };

	cout << "data1[0][0] = " << data1[0][0] << endl;
	cout << "data1[0][1] = " << data1[0][1] << endl;
	cout << "data1[1][0] = " << data1[1][0] << endl;
	cout << "data1[1][1] = " << data1[1][1] << endl;

	cout << endl;

	cout << "data2[0][0] = " << data2[0][0] << endl;
	cout << "data2[0][1] = " << data2[0][1] << endl;
	cout << "data2[0][2] = " << data2[0][2] << endl;
	cout << "data2[1][0] = " << data2[1][0] << endl;
	cout << "data2[1][0] = " << data2[1][1] << endl;
	cout << "data2[1][2] = " << data2[1][2] << endl;


	static char *name[]{
		"�λ�", "��ȭ", "�Ե�", "�Ｚ", "���", "����", "�ؼ�", "SK"
	};

	baceballTeam MyLike, YourLike;
	int i;

	MyLike = DRAGON;
	i = MyLike;
	cout << "���� �����ϴ� �߱��� = " << name[i] << endl;
	
	YourLike = baceballTeam(5);
	cout << "����� �����ϴ� �߱��� = " << name[YourLike] << endl;
	return 0;
}