#include "Ranking.h"
extern int playFifteenPuzzle(int dimension);
void main()
{
	int rank;
	int level = 3;
	cout << "3~5 ���� ���� : ";
	cin >> level;

	if (level == 3) {
		loadRanking("3x3_ranking.txt");
		rank = playFifteenPuzzle(level);
		printRanking();
		storeRanking("3x3_ranking.txt");
	}
	else if (level == 4) {
		loadRanking("4x4_ranking.txt");
		rank = playFifteenPuzzle(level);
		printRanking();
		storeRanking("4x4_ranking.txt");
	}
	else if (level == 5) {
		loadRanking("5x5_ranking.txt");
		rank = playFifteenPuzzle(level);
		printRanking();
		storeRanking("5x5_ranking.txt");
	}
	else {
		loadRanking("3x3_ranking.txt");
		rank = playFifteenPuzzle(level);
		printRanking();
		storeRanking("3x3_ranking.txt");
	}
}